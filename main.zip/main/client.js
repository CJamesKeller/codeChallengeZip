$(document).ready(function() {

  $("#submit").on("click", function() {
    
    if ( $("#firstName").val() && $("#lastName").val() && $("#email").val() &&
          $("#company").val() && $("#title").val() && $("#state").val() &&
          $("#country").val() && $("#additionalComments").val() ) {

      $("#submit").prop("disabled", true);
      displayData();
    }
    else {
      alert("Please fill out all fields");
    }
  });
});

var displayData = function() {

  var firstName           = $("#firstName").val();
  var lastName            = $("#lastName").val();
  var email               = $("#email").val();
  var company             = $("#company").val();
  var title               = $("#title").val();
  var state               = $("#state").val();
  var country             = $("#country").val();
  var additionalComments  = $("#additionalComments").val();

  $("#bottomDisplay").append("<table>" +
                                "<tr>" +
                                  "<td>First Name:</td>" +
                                  "<td>" + firstName + "</td>" +
                                "</tr>" +
                                "<tr>" +
                                  "<td>Last Name:</td>" +
                                  "<td>" + lastName + "</td>" +
                                "</tr>" +
                                "<tr>" +
                                  "<td>Email:</td>" +
                                  "<td>" + email + "</td>" +
                                "</tr>" +
                                "<tr>" +
                                  "<td>Company:</td>" +
                                  "<td>" + company + "</td>" +
                                "</tr>" +
                                "<tr>" +
                                  "<td>Title:</td>" +
                                  "<td>" + title + "</td>" +
                                "</tr>" +
                                "<tr>" +
                                  "<td>State:</td>" +
                                  "<td>" + state + "</td>" +
                                "</tr>" +
                                "<tr>" +
                                  "<td>Country:</td>" +
                                  "<td>" + country + "</td>" +
                                "</tr>" +
                                "<tr>" +
                                  "<td>Additional Comments:</td>" +
                                  "<td>" + additionalComments + "</td>" +
                                "</tr>" +
                              "</table>");
}
